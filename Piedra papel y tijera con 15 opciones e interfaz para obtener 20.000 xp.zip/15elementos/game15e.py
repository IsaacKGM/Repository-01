import PySimpleGUI as sg 
import random

reset = False
user_in = 0
images = ["tijera.png", "snake.png", "human.png", "tree.png", "wolf.png", "sponge.png", "papel.png", "air.png", "water.png", "dragon.png", "devil.png", "lightning.png", "gun.png", "rock.png", "fire.png"]


layout = [[sg.Button(key="-USER_IN-", image_filename=images[0]),
		   sg.Button("JUGAR!", size=(12,5), key="-PLAY-"), 
		   sg.Image(key="-COMP_IN-", size=(180,140))]]

window = sg.Window("el piedra pepel y tijera mas largo de la vida espero me de 20.000 xp.", layout=layout)

while True:
	event, values = window.read()

	if event == sg.WIN_CLOSED:
		break

	#control boton del usuario
	if event == "-USER_IN-":
		if not reset:
			user_in = (user_in+1)%14 #0, 1, 2, 3, 4,  0, 1, 2,....
			window["-USER_IN-"].update(image_filename=images[user_in])

	#control boton jugar
	if event == "-PLAY-":
		if not reset:
			comp_in = random.randint(0,14)
			window["-COMP_IN-"].update(filename=images[comp_in])
			window["-PLAY-"].update("RESET")

			#validar los resultados
			if user_in == comp_in:  #empate
				window["-PLAY-"].update(button_color=("white", "yellow"))

			elif user_in == 0:  #user tijera
				if comp_in==1:  #comp snake
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==2:  #comp human
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==3:  #comp tree
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==4:  #comp wolf
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==5:  #comp sponge
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==6:  #comp papel
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==7:  #comp air
					window["-PLAY-"].update(button_color=("white", "green"))	
				elif comp_in==8:  #comp water
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==9:  #comp dragon
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==10:  #comp devil
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==11:  #comp lightning
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==12:  #comp gun
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==13:  #comp rock
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==14:  #comp fire
					window["-PLAY-"].update(button_color=("white", "red"))		


			elif user_in == 1:  #user snake
				if comp_in==0:  #comp tijera
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==2:  #comp human
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==3:  #comp tree
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==4:  #comp wolf
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==5:  #comp sponge
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==6:  #comp papel
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==7:  #comp air
					window["-PLAY-"].update(button_color=("white", "green"))	
				elif comp_in==8:  #comp water
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==9:  #comp dragon
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==10:  #comp devil
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==11:  #comp lightning
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==12:  #comp gun
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==13:  #comp rock
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==14:  #comp fire
					window["-PLAY-"].update(button_color=("white", "red"))	

			elif user_in == 2:  #user human
				if comp_in==0:  #comp tijera
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==1:  #comp snake
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==3:  #comp tree
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==4:  #comp wolf
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==5:  #comp sponge
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==6:  #comp papel
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==7:  #comp air
					window["-PLAY-"].update(button_color=("white", "green"))	
				elif comp_in==8:  #comp water
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==9:  #comp dragon
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==10:  #comp devil
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==11:  #comp lightning
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==12:  #comp gun
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==13:  #comp rock
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==14:  #comp fire
					window["-PLAY-"].update(button_color=("white", "red"))	

			elif user_in == 3:  #user tree
				if comp_in==0:  #comp tijera
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==1:  #comp snake
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==2:  #comp human
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==4:  #comp wolf
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==5:  #comp sponge
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==6:  #comp papel
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==7:  #comp air
					window["-PLAY-"].update(button_color=("white", "green"))	
				elif comp_in==8:  #comp water
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==9:  #comp dragon
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==10:  #comp devil
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==11:  #comp lightning
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==12:  #comp gun
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==13:  #comp rock
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==14:  #comp fire
					window["-PLAY-"].update(button_color=("white", "red"))

			elif user_in == 4:  #user wolf
				if comp_in==0:  #comp tijera
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==1:  #comp snake
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==2:  #comp human
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==3:  #comp tree
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==5:  #comp sponge
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==6:  #comp papel
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==7:  #comp air
					window["-PLAY-"].update(button_color=("white", "green"))	
				elif comp_in==8:  #comp water
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==9:  #comp dragon
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==10:  #comp devil
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==11:  #comp lightning
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==12:  #comp gun
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==13:  #comp rock
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==14:  #comp fire
					window["-PLAY-"].update(button_color=("white", "red"))	

			elif user_in == 5:  #user sponge
				if comp_in==0:  #comp tijera
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==1:  #comp snake
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==2:  #comp human
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==3:  #comp tree
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==4:  #comp wolf
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==6:  #comp papel
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==7:  #comp air
					window["-PLAY-"].update(button_color=("white", "green"))	
				elif comp_in==8:  #comp water
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==9:  #comp dragon
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==10:  #comp devil
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==11:  #comp lightning
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==12:  #comp gun
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==13:  #comp rock
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==14:  #comp fire
					window["-PLAY-"].update(button_color=("white", "red"))	

			elif user_in == 6:  #user papel
				if comp_in==0:  #comp tijera
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==1:  #comp snake
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==2:  #comp human
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==3:  #comp tree
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==4:  #comp wolf
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==5:  #comp sponge
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==7:  #comp air
					window["-PLAY-"].update(button_color=("white", "green"))	
				elif comp_in==8:  #comp water
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==9:  #comp dragon
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==10:  #comp devil
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==11:  #comp lightning
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==12:  #comp gun
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==13:  #comp rock
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==14:  #comp fire
					window["-PLAY-"].update(button_color=("white", "red"))

			elif user_in == 7:  #user air
				if comp_in==0:  #comp tijera
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==1:  #comp snake
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==2:  #comp human
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==3:  #comp tree
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==4:  #comp wolf
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==5:  #comp sponge
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==6:  #comp papel
					window["-PLAY-"].update(button_color=("white", "red"))	
				elif comp_in==8:  #comp water
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==9:  #comp dragon
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==10:  #comp devil
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==11:  #comp lightning
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==12:  #comp gun
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==13:  #comp rock
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==14:  #comp fire
					window["-PLAY-"].update(button_color=("white", "green"))

			elif user_in == 8:  #user water
				if comp_in==0:  #comp tijera
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==1:  #comp snake
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==2:  #comp human
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==3:  #comp tree
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==4:  #comp wolf
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==5:  #comp sponge
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==6:  #comp papel
					window["-PLAY-"].update(button_color=("white", "red"))	
				elif comp_in==7:  #comp air
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==9:  #comp dragon
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==10:  #comp devil
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==11:  #comp lightning
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==12:  #comp gun
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==13:  #comp rock
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==14:  #comp fire
					window["-PLAY-"].update(button_color=("white", "green"))

			elif user_in == 9:  #user dragon
				if comp_in==0:  #comp tijera
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==1:  #comp snake
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==2:  #comp human
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==3:  #comp tree
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==4:  #comp wolf
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==5:  #comp sponge
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==6:  #comp papel
					window["-PLAY-"].update(button_color=("white", "red"))	
				elif comp_in==7:  #comp air
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==8:  #comp water
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==10:  #comp devil
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==11:  #comp lightning
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==12:  #comp gun
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==13:  #comp rock
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==14:  #comp fire
					window["-PLAY-"].update(button_color=("white", "green"))


			elif user_in == 10:  #user devil
				if comp_in==0:  #comp tijera
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==1:  #comp snake
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==2:  #comp human
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==3:  #comp tree
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==4:  #comp wolf
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==5:  #comp sponge
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==6:  #comp papel
					window["-PLAY-"].update(button_color=("white", "red"))	
				elif comp_in==7:  #comp air
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==8:  #comp water
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==9:  #comp dragon
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==11:  #comp lightning
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==12:  #comp gun
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==13:  #comp rock
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==14:  #comp fire
					window["-PLAY-"].update(button_color=("white", "green"))

			elif user_in == 11:  #user lightning
				if comp_in==0:  #comp tijera
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==1:  #comp snake
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==2:  #comp human
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==3:  #comp tree
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==4:  #comp wolf
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==5:  #comp sponge
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==6:  #comp papel
					window["-PLAY-"].update(button_color=("white", "red"))	
				elif comp_in==7:  #comp air
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==8:  #comp water
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==9:  #comp dragon
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==10:  #comp debil
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==12:  #comp gun
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==13:  #comp rock
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==14:  #comp fire
					window["-PLAY-"].update(button_color=("white", "green"))

			elif user_in == 12:  #user gun
				if comp_in==0:  #comp tijera
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==1:  #comp snake
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==2:  #comp human
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==3:  #comp tree
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==4:  #comp wolf
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==5:  #comp sponge
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==6:  #comp papel
					window["-PLAY-"].update(button_color=("white", "red"))	
				elif comp_in==7:  #comp air
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==8:  #comp water
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==9:  #comp dragon
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==10:  #comp debil
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==11:  #comp lightning
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==13:  #comp rock
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==14:  #comp fire
					window["-PLAY-"].update(button_color=("white", "green"))	

			elif user_in == 13:  #user rock
				if comp_in==0:  #comp tijera
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==1:  #comp snake
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==2:  #comp human
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==3:  #comp tree
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==4:  #comp wolf
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==5:  #comp sponge
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==6:  #comp papel
					window["-PLAY-"].update(button_color=("white", "red"))	
				elif comp_in==7:  #comp air
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==8:  #comp water
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==9:  #comp dragon
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==10:  #comp debil
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==11:  #comp lightning
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==12:  #comp gun
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==14:  #comp fire
					window["-PLAY-"].update(button_color=("white", "green"))	

			elif user_in == 14:  #user rock
				if comp_in==0:  #comp tijera
					window["-PLAY-"].update(button_color=("white", "green"))		
				elif comp_in==1:  #comp snake
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==2:  #comp human
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==3:  #comp tree
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==4:  #comp wolf
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==5:  #comp sponge
					window["-PLAY-"].update(button_color=("white", "green"))
				elif comp_in==6:  #comp papel
					window["-PLAY-"].update(button_color=("white", "green"))	
				elif comp_in==7:  #comp air
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==8:  #comp water
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==9:  #comp dragon
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==10:  #comp debil
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==11:  #comp lightning
					window["-PLAY-"].update(button_color=("white", "red"))
				elif comp_in==12:  #comp gun
					window["-PLAY-"].update(button_color=("white", "red"))		
				elif comp_in==13:  #comp fire
					window["-PLAY-"].update(button_color=("white", "red"))	


	
		#si dice RESET, se reeinicia el juego
		else:
			window["-PLAY-"].update("JUGAR!", button_color=("white", sg.theme_background_color()))
			window["-USER_IN-"].update(image_filename=images[0])
			window["-COMP_IN-"].ipdate(filename=None)

		#intercambio de la variable reset
		reste = not reset

window.close()

